package tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;
import java.io.IOException;
import java.util.List;

import framework.Browser;
import framework.Browser.Browsers;
import framework.ToDoTask.ToDoTaskElements;

import framework.Utilities;
//import framework.ToDoTask;
//import framework.ToDoTask.ToDoTaskElements;

public class ToDoTasks {
	
	ToDoTasks(){System.out.println("New task is created");}
	    
	private Browser browser = new Browser();

	@Test(description = "Open URL in Firefox", priority = 1, enabled = true)
	public void openToDoApp() throws IOException {
	    browser.setupWebDriver(Browsers.Firefox);
	    Utilities.driver.get("http://cburgdorf.github.io/angular-todo-app/");
	}
	    
	@Test(description = "Add tasks", priority = 2, enabled = true)
	public void addTasks(){
		int i;
		for (i=1; i < 4; i++){
			WebElement textfield = Utilities.driver.findElement(By.cssSelector(ToDoTaskElements.ADD_NEW_TODO_TASK_NAME.getCss()));
			Utilities.fillTextField(textfield, "Task " + i);
			Utilities.sleep(1000);
			WebElement entertask = Utilities.driver.findElement(By.cssSelector(ToDoTaskElements.ADD_NEW_TODO_TASK.getCss()));
			Utilities.sendEnter(entertask);
		}
	}

	@Test(description = "Edit task 2", priority = 3, enabled = true)
	public void editTask2(){
		List<WebElement> tasks = Utilities.driver.findElements(By.cssSelector(ToDoTaskElements.TODO_LIST.getCss()));
		WebElement task2 = tasks.get(1);
		task2.click();
		Utilities.fillTextField(task2, " Edited");
		Utilities.sendEnter(task2);
	}
	
	@Test(description = "Remove task 2", priority = 4, enabled = true)
	public void removeTask2(){
		List<WebElement> remove_tasks = Utilities.driver.findElements(By.cssSelector(ToDoTaskElements.REMOVE_TASK.getCss()));
		WebElement remove_task2 = remove_tasks.get(1);
		remove_task2.click();
	}
	
	@Test(description = "Complete task 1", priority = 5, enabled = true)
	public void completeTask1(){
		List<WebElement> checkboxes = Utilities.driver.findElements(By.cssSelector(ToDoTaskElements.CHECK.getCss()));
		WebElement checkbox_task1 = checkboxes.get(0);
		checkbox_task1.click();
		Utilities.sleep(1000);
		Assert.assertTrue(Utilities.driver.findElement(By.cssSelector(ToDoTaskElements.STATUS_CHECK_TASK.getCss())).isDisplayed(), "The task is not completed");
		Assert.assertTrue(Utilities.driver.findElement(By.cssSelector(ToDoTaskElements.CLEAR_COMPLETED_TASKS.getCss())).isDisplayed(), "There is no possibility to clear the completed tasks");
	}
	
	@Test(description = "Undo completion of task 1", priority = 6, enabled = true)
	public void undoCompletionTask1(){
		List<WebElement> checkboxes = Utilities.driver.findElements(By.cssSelector(ToDoTaskElements.CHECK.getCss()));
		WebElement checkbox_task1 = checkboxes.get(0);
		checkbox_task1.click();
		Utilities.sleep(1000);
		Assert.assertFalse(Utilities.driver.findElement(By.cssSelector(ToDoTaskElements.CLEAR_COMPLETED_TASKS.getCss())).isDisplayed(), "The possibility to clear the completed tasks is available");
	}

	@Test(description = "Number of tasks", priority = 7, enabled = true)
	public void numberTasks(){
		List<WebElement> numberTasks = Utilities.driver.findElements(By.cssSelector(ToDoTaskElements.TODO_LIST.getCss()));
		Assert.assertEquals(numberTasks.size(), 2);
	}
	
	@Test(description = "Clear complete task", priority = 8, enabled = true)
	public void clearCompleteTask(){
		List<WebElement> checkboxes = Utilities.driver.findElements(By.cssSelector(ToDoTaskElements.CHECK.getCss()));
		WebElement checkbox_task1 = checkboxes.get(0);
		checkbox_task1.click();
		Utilities.sleep(1000);
		WebElement clear_task = Utilities.driver.findElement(By.cssSelector(ToDoTaskElements.CLEAR_COMPLETED_TASKS.getCss()));
		clear_task.click();
		List<WebElement> numberTasks = Utilities.driver.findElements(By.cssSelector(ToDoTaskElements.TODO_LIST.getCss()));
		Assert.assertEquals(numberTasks.size(), 1);
	}
	
	@Test(description = "Close Firefox", priority = 9, enabled = true)
	public void CloseApp() throws IOException {
	     Utilities.driver.quit();
	}
}
