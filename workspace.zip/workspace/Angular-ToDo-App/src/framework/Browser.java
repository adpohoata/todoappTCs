package framework;

import org.testng.annotations.AfterClass;

import java.io.IOException;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class Browser {
	public enum Browsers {
	    Firefox, Chrome, IE
	}
	
	public void setupWebDriver(Browsers browser) throws IOException {
           switch (browser) {
           case Firefox:
            	//gecko driver suplement step is required only when FF version is bigger than 47 and Selenium version is at least 3.0
    			System.setProperty("webdriver.gecko.driver","D:\\other\\todo\\installed_tools\\geckodriver.exe");
                FirefoxProfile profile = new FirefoxProfile();
                profile.setPreference("datareporting.healthreport.uploadEnabled", false);
                profile.setPreference("datareporting.healthreport.service.enabled", false);
                profile.setPreference("datareporting.healthreport.service.firstRun", false);
                Utilities.driver = new FirefoxDriver(profile);
                break;
            case Chrome:
                System.setProperty("webdriver.chrome.driver","D:\\other\\todo\\installed_tools\\chromedriver_win32\\chromedriver.exe");	
                ChromeOptions options = new ChromeOptions();
                options.addArguments("start-maximized");
                Utilities.driver = new ChromeDriver(options);
                break;
            case IE:
            	System.setProperty("webdriver.ie.driver","D:\\other\\todo\\installed_tools\\IEDriverServer_x64_3.4.0\\IEDriverServer.exe");
                Utilities.driver = new InternetExplorerDriver();
                break;
        }
	}	
	 
	@AfterClass(alwaysRun = true)
    public void afterClass() {Utilities.driver.quit();}	
	
}
  	