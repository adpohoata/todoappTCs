package framework;

public class ToDoTask {
	public enum ToDoTaskElements {
        TODO_FORM(".content .ng-directive"),
        ADD_NEW_TODO_TASK_NAME(".content .ng-directive"),
        ADD_NEW_TODO_TASK(".content .ng-directive .ui-tooltip-top"),
        TODO_LIST(".content .todo"),
        EDIT(".edit .todo-input"),
        CHECK(".check"),
        EDIT_TASK(".content .todo.editing-true"),
        REMOVE_TASK(".content .todo .display .todo-destroy"),
        CHECK_TASK(".content .todo .display [name='todo.done']"),
        STATUS_CHECK_TASK(".content .todo.done-true"),
        NUMBER_TASKS(".content .todo-count .number"),
        CLEAR_COMPLETED_TASKS(".content .todo-clear");
        

		private final String id;

		ToDoTaskElements(String id) {
	            this.id = id;
	        }

	    public String getCss() {
	        return id;
	    }
    }
}
