package framework;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.Keys;


public class Utilities {
	    public static WebDriver driver;
	   
	    public static void sendEnter(WebElement field) {
	        field.sendKeys(Keys.RETURN);
	        sleep(2000);
	    }

	    public static boolean isDisabled(WebElement el) {
	        return !el.isDisplayed();
	    }

	    public static void fillTextField(WebElement textfield, String text) {
	        textfield.click();
	        textfield.sendKeys(text);
	    }

	    public static void sleep(int i) {
	        try {
	            Thread.sleep(i);
	        } catch (InterruptedException ex) {
	            Thread.currentThread().interrupt();
	        }
	    }

	}


